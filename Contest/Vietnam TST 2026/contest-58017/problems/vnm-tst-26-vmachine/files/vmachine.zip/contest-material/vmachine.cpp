#include "vmachinelib.h"
void solve(int N){

}
