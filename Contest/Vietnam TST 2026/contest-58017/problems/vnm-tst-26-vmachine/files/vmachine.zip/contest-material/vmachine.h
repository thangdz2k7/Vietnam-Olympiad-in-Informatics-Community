#include <bits/stdc++.h>

namespace Jury{

void wa(std::string msg){
  std::cout << "Wrong answer (" << msg << ")";
  exit(0);
}

const int SIZE = 2000;
const int LIMIT = 4e6;

int N, used[205], op;
std::vector<std::pair<int, int>> treeEdges;
std::vector<int> tour;
int16_t A[SIZE];

void reset(){
  op = 0;
  treeEdges.clear();
  tour.clear();
  std::fill(used, used + 205, 0);
}

void init(){
  for(int i = 0; i < SIZE; ++i){
    A[i] = 0;
  }
  for(int i = 0; i < N - 1; ++i){
    A[2 * i] = treeEdges[i].first;
    A[2 * i + 1] = treeEdges[i].second;
  }
}

void checkPos(int i){
  if(!(0 <= i && i < SIZE)) wa("invalid index call");
}

void addOp(){
  if((++op) > LIMIT) wa("exceeded maximum number of operations");
}

void sub(int i, int j, int k){
  checkPos(i);
  checkPos(j);
  checkPos(k);
  A[k] = A[i] - A[j];
  addOp();
}

void mul(int i, int j, int k){
  checkPos(i);
  checkPos(j);
  checkPos(k);
  A[k] = A[i] * A[j];
  addOp();
}

void cmp(int i, int j, int k){
  checkPos(i);
  checkPos(j);
  checkPos(k);
  A[k] = (A[i] == A[j]);
  addOp();
}

void print(int i){
  checkPos(i);
  int u = A[i];
  if(!(1 <= u && u <= N)) wa("invalid index vertex");
  if(used[u]) wa("appeared");
  tour.emplace_back(u);
  used[u] = 1;
}

int pos[205];
void checkAnswer(){
  if((int)tour.size() < N) wa("print less than N times");
  for(int i = 0; i < N; ++i) pos[tour[i]] = i;
  for(int i = 0; i < N - 1; ++i){
    int u, v;
    std::tie(u, v) = treeEdges[i];
    if(!(pos[u] < pos[v])) wa("wrong order");
  }
}

}

void print(int i){
  Jury::print(i);
}
void sub(int i, int j, int k){
  Jury::sub(i, j, k);
}
void mul(int i, int j, int k){
  Jury::mul(i, j, k);
}
void cmp(int i, int j, int k){
  Jury::cmp(i, j, k);
}
void solve(int N);

int main(){
  int T;
  std::cin >> T;
  for(int t = 0; t < T; ++t){
    int N; 
    std::cin >> N;
    Jury::N = N;
    for(int i = 0; i < N - 1; ++i){
      int u, v;
      std::cin >> u >> v;
      Jury::treeEdges.emplace_back(u, v);
    }
    Jury::init();
    solve(N);
    Jury::checkAnswer();
    Jury::reset();
  }
  std::cout << "Accepted";
  return 0;
}