#include<cstring>
int ask(std::string s);
