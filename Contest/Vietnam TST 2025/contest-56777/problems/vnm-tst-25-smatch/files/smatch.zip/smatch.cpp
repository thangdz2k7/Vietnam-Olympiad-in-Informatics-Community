#include<bits/stdc++.h>
using namespace std;
string solve(){
	return "abcd";
}
