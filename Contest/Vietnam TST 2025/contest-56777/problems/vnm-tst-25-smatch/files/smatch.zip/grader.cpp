#include<bits/stdc++.h>
#include "smatchlib.h"
using namespace std;
int main(){
	int n, l, r;
	cin >> n >> l >> r;
	cout << "your answer: " << solve();
}
