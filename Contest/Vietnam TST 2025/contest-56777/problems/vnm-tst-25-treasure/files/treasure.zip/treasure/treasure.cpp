#include "treasurelib.h" 

void solveAlice(vector<int> S) {

}

void solveBob(vector<int> S) {
    
}