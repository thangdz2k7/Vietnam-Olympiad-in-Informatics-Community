#include <bits/stdc++.h>
using namespace std;

namespace Jury {
    const int N = 1e5 + 5;
    int n, state[N];
    vector<int> adj[N];
    int cnt, cur, label[N];
    
    vector<pair<int, int>> info;
    
    void init(int start, bool isAlice) {
        for (int i = 1; i <= n; i++){
            label[i] = 0;
            if (isAlice) state[i] = rand() % 2;
        }
        cur = start;
        label[cur] = cnt = 1;
    }
    
    vector<int> getS() {
        info.clear(), info.emplace_back(state[cur], 0);
        for (int x : adj[cur]) info.emplace_back(label[x], x);
        while (info.size() < 4) info.emplace_back(-1, -1);
        shuffle(info.begin() + 1, info.end(), mt19937());
        return {info[0].first, info[1].first, info[2].first, info[3].first};
    }
    
    vector<int> move(int i) {
        cur = info[i].second;
        if (label[cur] == 0) label[cur] = ++cnt;
        return getS();
    }
    
    void flip() {
        state[cur] ^= 1;
    }
}

vector<int> move(int i) {
    return Jury::move(i);
}

void flip() {
    return Jury::flip();
}

void solveAlice(vector<int> S);
void solveBob(vector<int> S);

int main() {
    freopen("input.txt", "r", stdin);
    cin >> Jury::n;
    for (int i = 1; i < Jury::n; i++) {
        int u, v;
        cin >> u >> v;
        Jury::adj[u].push_back(v);
        Jury::adj[v].push_back(u);
    }

    int Alice, Bob;
    cin >> Alice >> Bob;

    Jury::init(Alice, true);
    solveAlice(Jury::getS());
    Jury::init(Bob, false);
    solveBob(Jury::getS());

    if (Jury::cur != Alice) cout << "Wrong answer" << endl;
    else cout << "Accepted" << endl;
}